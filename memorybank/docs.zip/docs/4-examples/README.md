# Part IV: Examples

Code samples and walkthroughs.

[← Back to Main](../../README.md)

---

## Content
- **[Scenarios](example-scenarios.md)** - Common gameplay flows (Setup, Turns).
- **[Testing](testing.md)** - Unit and Integration testing patterns.

---

[← Back to Main](../../README.md)
