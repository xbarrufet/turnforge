﻿namespace TurnForge.Adapters.Godot;

public class Class1
{

}
