using TurnForge.Engine.Entities.Board.Interfaces;

namespace TurnForge.Rules.BarelyAlive.Traits;

public interface IZoneTrait : IAreaBehaviour
{
}
