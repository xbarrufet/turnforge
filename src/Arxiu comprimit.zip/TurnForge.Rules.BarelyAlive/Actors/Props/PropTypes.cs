namespace TurnForge.Rules.BarelyAlive.Actors;

public class PropTypes
{
    public const string PartySpawn = "BarelyAlive.PartySpawn";
    public const string ZombieSpawn = "BarelyAlive.ZombieSpawn";
}