namespace TurnForge.Rules.BarelyAlive.Dto;

public class ZoneTraitDto
{
    public string Type { get; set; } = string.Empty;
}
