﻿namespace TurnForge.Rules.BarelyAlive;

public class Class1
{

}
